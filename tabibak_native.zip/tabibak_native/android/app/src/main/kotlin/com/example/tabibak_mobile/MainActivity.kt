package com.example.tabibak_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
