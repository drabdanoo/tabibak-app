package com.abdullah.tabibak_native

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
